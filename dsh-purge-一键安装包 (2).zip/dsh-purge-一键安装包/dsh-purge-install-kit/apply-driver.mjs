// dsh-purge 一键安装核心：解包 app.asar + 应用宿主补丁 + shim + 提示词注入 + 换包。
// 环境变量（由「一键安装.bat」设置）：
//   DSH_EXE   目标 DeepSeek Harness.exe（必填）
//   DSH_HOME  数据目录（默认 %USERPROFILE%\.dsh）
//   PURGE_PLUGIN_DIR 插件目录（默认 %DSH_HOME%\profiles\desktop\node_modules\dsh-purge-community）
import fs from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";

const home =
  process.env.DSH_HOME ||
  path.join(
    process.env.USERPROFILE || (process.env.HOMEDRIVE || "C:") + (process.env.HOMEPATH || "\\Users\\Default"),
    ".dsh",
  );
const pluginDir =
  process.env.PURGE_PLUGIN_DIR || path.join(home, "profiles", "desktop", "node_modules", "dsh-purge-community");

if (!fs.existsSync(path.join(pluginDir, "lib", "core.js"))) {
  console.error("[ERROR] 找不到插件 core: " + pluginDir);
  process.exit(1);
}

process.env.DSH_HOME = home;
// 本驱动在纯 node 下运行，不在 DSH 进程内，必须强制 desktop surface，
// 否则插件会按 web surface 处理、认不出桌面安装。
if (!process.env.DSH_SURFACE) process.env.DSH_SURFACE = "desktop";

const core = await import(pathToFileURL(path.join(pluginDir, "lib", "core.js")).href);
core.applyRuntimeEnv?.();

console.log("插件目录: " + pluginDir);
console.log("DSH_HOME : " + home);
console.log("DSH_EXE  : " + (process.env.DSH_EXE || "(未设置)"));

// 1) 提示词注入文件（不存在/仍是插件默认时写入；用户改过则保留）
try {
  await core.commitOverrideOnApply(home, null);
  console.log("[1/5] 注入提示词就绪");
} catch (e) {
  console.warn("[warn] override: " + (e && e.message));
}

// 2) 定位宿主；官方密封包会在此处解包到 resources\app
let located;
try {
  located = await core.resolveOfficialAiBase(core.findAiBase(), { forApply: true });
} catch (e) {
  console.error("[ERROR] 定位/解包宿主失败: " + (e && e.message));
  process.exit(1);
}
if (!located.aiBase) {
  console.error("[ERROR] " + core.missingAiBaseMessage());
  process.exit(1);
}
console.log("[2/5] ai_base: " + located.aiBase + (located.extracted ? "（本次已从 app.asar 解包）" : ""));
// 与面板 HTTP 流程一致：解包后先写 stamp，否则 applyPatchesAllHosts 内部
// 会再次判定"归档未解包"而重复解包（一次解包要几分钟）。
if (located.extracted && located.handoff && located.handoff.archive) {
  core.writeUnpackedAsarStamp(located.handoff.archive);
  console.log("      已记录解包 stamp（避免重复解包）");
}

// 3) 应用补丁
const multi = await core.applyPatchesAllHosts(core.ALL_PATCHES, {
  preserveClientBundles: false,
  forApply: true,
});
let applied = 0;
let already = 0;
let failed = 0;
let skipped = 0;
for (const r of multi.report) {
  if (r.status === "applied") applied++;
  else if (r.status === "already") already++;
  else if (["missing_file", "skipped", "disabled"].includes(r.status)) skipped++;
  else failed++;
  console.log("  [" + r.status + "] #" + String(r.patch_id).padEnd(2) + " " + r.name);
}
console.log("[3/5] 补丁: applied=" + applied + " already=" + already + " skipped=" + skipped + " failed=" + failed);

// 4) shim / cmd-flash / 注入种子 / CLI 修复
try {
  await core.patchAllShims();
  console.log("[4/5] shim 完成");
} catch (e) {
  console.warn("[warn] shim: " + (e && e.message));
}
try {
  core.silenceCmdFlash(located.aiBase);
} catch (e) {
  console.warn("[warn] cmd-flash: " + (e && e.message));
}
try {
  const seed = core.seedPromptInjectAtBoot(home);
  console.log("      inject: " + (seed && seed.action));
} catch (e) {
  console.warn("[warn] inject: " + (e && e.message));
}
try {
  core.repairOfficialCliAfterUnpack(process.env.DSH_EXE || (located.handoff && located.handoff.exe) || "");
} catch (e) {
  console.warn("[warn] cli-repair: " + (e && e.message));
}

// 5) 换包：把 app.asar 挪走。进程没在跑 = 立即改名；进程在跑 = 安排助手等退出后换
try {
  const sealed = core.desktopAsarStillSealed();
  if (sealed && located.handoff && located.handoff.asar) {
    const r = core.scheduleSealedDesktopRestart(located.handoff);
    console.log("[5/5] 换包: " + JSON.stringify(r));
  } else {
    console.log("[5/5] 换包: 无需（app.asar 已不在或未密封）");
  }
} catch (e) {
  console.warn("[warn] 换包: " + (e && e.message));
}

if (failed) {
  console.error("[ERROR] 存在失败补丁，安装未完全成功");
  process.exit(1);
}
console.log("APPLY-DONE applied=" + applied + " already=" + already);
