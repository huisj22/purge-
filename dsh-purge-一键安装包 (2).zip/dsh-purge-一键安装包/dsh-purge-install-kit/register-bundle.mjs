// dsh-purge 一键安装：把插件注册进 DSH profile（package.json 的依赖 + bundles 条目）
// 用法: node register-bundle.mjs <profileDir> <tgzAbs>
import fs from "node:fs";
import path from "node:path";

const [profileDir, tgzAbs] = process.argv.slice(2);
if (!profileDir || !tgzAbs) {
  console.error("用法: register-bundle.mjs <profileDir> <tgzAbs>");
  process.exit(2);
}
const pjPath = path.join(profileDir, "package.json");
let data = {};
if (fs.existsSync(pjPath)) {
  try {
    data = JSON.parse(fs.readFileSync(pjPath, "utf8"));
  } catch {
    data = {};
  }
}
if (typeof data !== "object" || data === null || Array.isArray(data)) data = {};

const spec = "file:" + path.resolve(tgzAbs).replace(/\\/g, "/");
data.dependencies = data.dependencies || {};
data.dependencies["dsh-purge-community"] = spec;
data.dsh = data.dsh || {};
data.dsh.profile = data.dsh.profile || {};
data.dsh.profile.bundles = Array.isArray(data.dsh.profile.bundles) ? data.dsh.profile.bundles : [];
if (!data.dsh.profile.bundles.includes("dsh-purge-community")) {
  data.dsh.profile.bundles.push("dsh-purge-community");
}
fs.mkdirSync(profileDir, { recursive: true });
fs.writeFileSync(pjPath, JSON.stringify(data, null, 2) + "\n", "utf8");
console.log("已注册 bundle: " + spec);
