@echo off
chcp 65001 >nul
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title dsh-purge 卸载还原

echo ============================================================
echo   dsh-purge 卸载还原（恢复原版 DSH）
echo ============================================================
echo.

set "DSH_DIR=%LOCALAPPDATA%\Programs\DeepSeek Harness"
if not "%~1"=="" set "DSH_DIR=%~1"
set "DSH_EXE=%DSH_DIR%\DeepSeek Harness.exe"
if not exist "%DSH_EXE%" (
  echo [错误] 找不到 DSH: "%DSH_EXE%"
  echo 用法: "%~nx0" ["DSH 安装目录"]
  goto :end
)

if not defined DSH_HOME set "DSH_HOME=%USERPROFILE%\.dsh"
set "PROFILE=%DSH_HOME%\profiles\desktop"
set "NODE=%DSH_DIR%\resources\runtime\primary-runtime\dependencies\node\bin\node.exe"
if not exist "%NODE%" set "NODE=%DSH_DIR%\resources\app\runtime\primary-runtime\dependencies\node\bin\node.exe"

echo [1/4] 关闭 DSH...
taskkill /IM "DeepSeek Harness.exe" /F >nul 2>nul
timeout /t 3 /nobreak >nul

echo [2/4] 恢复原始 app.asar（若存在备份）...
set "BAK="
for /f "delims=" %%f in ('dir /b "%DSH_DIR%\resources\app.asar.purge-*.bak" 2^>nul') do set "BAK=%DSH_DIR%\resources\%%f"
if not defined BAK if exist "%DSH_DIR%\resources\app.asar.bak" set "BAK=%DSH_DIR%\resources\app.asar.bak"
if defined BAK (
  echo   发现备份: !BAK!
  if exist "%DSH_DIR%\resources\app" (
    echo   删除补丁目录 resources\app ...
    rmdir /S /Q "%DSH_DIR%\resources\app"
  )
  move /Y "!BAK!" "%DSH_DIR%\resources\app.asar" >nul
  echo   已还原 app.asar
) else (
  echo   未发现 app.asar 备份（可能从未换包），跳过。
)

echo [3/4] 移除插件与注册...
if exist "%NODE%" "%NODE%" "%~dp0unregister-bundle.mjs" "%PROFILE%"
if exist "%PROFILE%\node_modules\dsh-purge-community" rmdir /S /Q "%PROFILE%\node_modules\dsh-purge-community"
if exist "%DSH_HOME%\prompt-inject.md" echo   注: 保留 %DSH_HOME%\prompt-inject.md（用户文件，不需要可手动删除）

echo [4/4] 启动 DSH...
if exist "%DSH_EXE%" start "" "%DSH_EXE%"

echo.
echo 卸载还原完成：DSH 已回到原版（app.asar + 原提示词）。
echo.
pause
exit /b 0

:end
pause
exit /b 1
