// dsh-purge 卸载：从 DSH profile 移除插件注册（不动宿主文件）
// 用法: node unregister-bundle.mjs <profileDir>
import fs from "node:fs";
import path from "node:path";

const profileDir = process.argv[2];
if (!profileDir) {
  console.error("用法: unregister-bundle.mjs <profileDir>");
  process.exit(2);
}
const pjPath = path.join(profileDir, "package.json");
let data = {};
if (fs.existsSync(pjPath)) {
  try {
    data = JSON.parse(fs.readFileSync(pjPath, "utf8"));
  } catch {
    data = {};
  }
}
if (data.dependencies) delete data.dependencies["dsh-purge-community"];
if (data.dsh && data.dsh.profile && Array.isArray(data.dsh.profile.bundles)) {
  data.dsh.profile.bundles = data.dsh.profile.bundles.filter((b) => b !== "dsh-purge-community");
}
fs.writeFileSync(pjPath, JSON.stringify(data, null, 2) + "\n", "utf8");
console.log("已移除 bundle 注册");
