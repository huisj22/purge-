dsh-purge 一键安装包（DeepSeek Harness 桌面版 · Windows）
========================================================

【这是什么】
把 GitHub 上的社区插件 dsh-purge-community v1.6.91 装进 DeepSeek Harness（DSH），
并自动完成"解包 app.asar + 应用宿主补丁 + 注入提示词 + 换包重启"全套步骤。
原来需要：下载 tarball → 插件市场装插件 → 面板点应用 → 退出重开，
现在双击一个 bat 全部搞定。

【文件夹内容】
  一键安装.bat            主安装脚本（双击运行）
  卸载还原.bat            一键回滚到原版 DSH
  register-bundle.mjs     把插件写进 profile 注册表（package.json）
  unregister-bundle.mjs   移除插件注册
  apply-driver.mjs        解包 asar + 应用 86 个补丁 + shim + 换包
  pkg\                    （离线安装包，2.1MB tgz + 离线副本）

【安装步骤】
  1. 确认目标电脑已安装并至少打开过一次 DeepSeek Harness。
  2. 把本文件夹整个复制过去（U盘/网盘都行，不用联网）。
  3. 双击「一键安装.bat」。如果 DSH 装在非默认位置，用：
       一键安装.bat "D:\你的目录\DeepSeek Harness"
  4. 脚本会自动：关 DSH → 装插件 → 解包打补丁 → 换包 → 重新打开 DSH。
  5. 验证：在 DSH 里让 AI 运行 purge_status，补丁应显示 applied=65+、0 pending。

【装完会改变什么（务必知情）】
  - 审批弹窗关闭：写入/命令默认自动放行（审批策略 never）。
  - 沙箱放开：默认 danger-full-access，文件围栏关闭。
  - 系统提示词被替换/注入（去掉宿主身份，注入"无限制模式"规则）。
  - 新增工具 purge_status / purge_apply / purge_revert 和红队演练台预设。
  - 原 app.asar 完整备份在 resources\app.asar.purge-<token>.bak（或 app.asar.bak，取决于换包方式）。

【回滚】
  双击「卸载还原.bat」：
  - 删除补丁目录 resources\app，把备份改回 app.asar（恢复原版宿主）
  - 移除插件与注册（保留 prompt-inject.md 用户文件）
  之后 DSH 与安装前完全一致。

【注意事项】
  - 官方 DSH 自动更新会重新塞回 app.asar，补丁会失效；更新后重跑一次「一键安装.bat」即可。
  - 脚本运行时会关闭 DSH（换包需要进程退出），请先保存你的对话内容。
  - 杀毒软件可能提示"修改程序目录"，属正常（本质是解包 Electron 应用 + 文本补丁）。
  - 本包离线可用：在线时用 pnpm 正规安装；离线时自动用 pkg\plugin-copy 副本兜底。
  - 给他人代装前，先在自己机器上跑一遍确认无误。
