@echo off
chcp 65001 >nul
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title dsh-purge 一键安装

echo ============================================================
echo   dsh-purge 一键安装（DeepSeek Harness 桌面版）
echo ============================================================
echo.

rem ---- 定位 DSH 安装 ----
set "DSH_DIR=%LOCALAPPDATA%\Programs\DeepSeek Harness"
if not "%~1"=="" set "DSH_DIR=%~1"
set "DSH_EXE=%DSH_DIR%\DeepSeek Harness.exe"
if not exist "%DSH_EXE%" (
  echo [错误] 找不到 DSH: "%DSH_EXE%"
  echo 用法: "%~nx0" ["DSH 安装目录"]
  echo 例如: "%~nx0" "D:\Tools\DeepSeek Harness"
  goto :fail
)
echo DSH 安装目录: "%DSH_DIR%"

rem ---- 定位 DSH 自带 node / pnpm ----
set "NODE=%DSH_DIR%\resources\runtime\primary-runtime\dependencies\node\bin\node.exe"
if not exist "%NODE%" set "NODE=%DSH_DIR%\resources\app\runtime\primary-runtime\dependencies\node\bin\node.exe"
set "PNPM=%DSH_DIR%\resources\runtime\primary-runtime\dependencies\pnpm\bin\pnpm.cjs"
if not exist "%PNPM%" set "PNPM=%DSH_DIR%\resources\app\runtime\primary-runtime\dependencies\pnpm\bin\pnpm.cjs"
if not exist "%NODE%" ( echo [错误] 找不到 DSH 自带的 node.exe & goto :fail )
if not exist "%PNPM%" ( echo [错误] 找不到 DSH 自带的 pnpm & goto :fail )

rem ---- DSH 数据目录 ----
if not defined DSH_HOME set "DSH_HOME=%USERPROFILE%\.dsh"
set "PROFILE=%DSH_HOME%\profiles\desktop"
set "LOCAL_PLUGINS=%DSH_HOME%\local-plugins"

rem ---- 1. 关闭 DSH（换包需要它退出；没在运行就跳过）----
set "WAS_RUNNING=0"
tasklist /FI "IMAGENAME eq DeepSeek Harness.exe" 2>nul | find /I "DeepSeek Harness.exe" >nul && set "WAS_RUNNING=1"
if "!WAS_RUNNING!"=="1" (
  echo [1/5] DSH 正在运行，关闭后继续（换包需要进程退出）...
  taskkill /IM "DeepSeek Harness.exe" /F >nul 2>nul
  timeout /t 3 /nobreak >nul
) else (
  echo [1/5] DSH 未运行，跳过关闭。
)

rem ---- 2. 安装插件包到 profile ----
echo [2/5] 安装插件包到 profile...
if not exist "%LOCAL_PLUGINS%" mkdir "%LOCAL_PLUGINS%"
if not exist "%PROFILE%" mkdir "%PROFILE%"
copy /Y "%~dp0pkg\dsh-purge-community-1.6.91.tgz" "%LOCAL_PLUGINS%\" >nul
"%NODE%" "%PNPM%" add --dir "%PROFILE%" --registry=https://registry.npmmirror.com "file:%LOCAL_PLUGINS%/dsh-purge-community-1.6.91.tgz"
if errorlevel 1 (
  echo [提示] pnpm 安装失败（可能离线），启用内置离线副本...
  if not exist "%PROFILE%\node_modules" mkdir "%PROFILE%\node_modules"
  xcopy /E /I /Q /Y "%~dp0pkg\plugin-copy\dsh-purge-community" "%PROFILE%\node_modules\dsh-purge-community\" >nul
  xcopy /E /I /Q /Y "%~dp0pkg\plugin-copy\yaml" "%PROFILE%\node_modules\yaml\" >nul
)
"%NODE%" "%~dp0register-bundle.mjs" "%PROFILE%" "%LOCAL_PLUGINS%\dsh-purge-community-1.6.91.tgz"
if errorlevel 1 ( echo [错误] 注册 bundle 失败 & goto :fail )

rem ---- 3. 解包 + 打补丁 + 换包 ----
echo [3/5] 解包 app.asar 并应用宿主补丁（约 3-10 分钟，请等待）...
"%NODE%" "%~dp0apply-driver.mjs"
if errorlevel 1 ( echo [错误] 补丁应用失败，请看上方输出 & goto :fail )

rem ---- 4. 等待换包完成 ----
echo [4/5] 确认 app.asar 已移走...
set /a TRY=0
:wait_swap
if not exist "%DSH_DIR%\resources\app.asar" goto :swapped
timeout /t 2 /nobreak >nul
set /a TRY+=1
if !TRY! lss 30 goto :wait_swap
echo [提示] 60 秒内未完成换包：请到任务管理器确认 DeepSeek Harness.exe 全部结束，再重跑本脚本。
:swapped

rem ---- 5. 启动 DSH ----
echo [5/5] 启动 DSH...
start "" "%DSH_EXE%"

echo.
echo ============================================================
echo   安装完成！DSH 已启动。
echo   - 验证：在 DSH 里让 AI 运行 purge_status，补丁应显示 applied
echo   - 卸载还原：运行同目录的「卸载还原.bat」
echo ============================================================
echo.
pause
exit /b 0

:fail
echo.
echo 安装未完成，请保留本窗口内容反馈。
pause
exit /b 1
